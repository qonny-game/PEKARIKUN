// ==========================================
// JS/game/reel-spin.js  —  リール回転・目押し停止・予告・役の結果
// 読み込み順は index.html の <script> 並びどおり。グローバル変数で共有するので順序を変えない。
// ==========================================
/* ---------- リール回転: レバーONで回り、自分で3つ止める ---------- */
const OPT_KEY = 'pekari-opt-v1';
let AUTO_STOP = false;   // 自動停止 (目押しなし。7もスイカも必ず揃う)
try { AUTO_STOP = !!JSON.parse(localStorage.getItem(OPT_KEY) || '{}').autoStop; } catch (e) { /* 初期値 */ }
function saveOpt() { try { localStorage.setItem(OPT_KEY, JSON.stringify({ autoStop: AUTO_STOP })); } catch (e) { /* 無視 */ } }

const SPIN_SPEED = 28;    // 1秒に流れる図柄の数 (日本機と同じ: 80回転/分 = 1周0.75秒 = 21コマ/0.75秒)
const wideCands = (s, n) => Array.from({ length: n + 1 }, (_, d) => s + d);
/* c番目のリールの r段(0上/1中/2下)に、pred を満たす図柄が来る停止位置 t をランダムに1つ (windowOf の中段 = t) */
function stopWhere(c, r, pred) { const ts = []; STRIPS[c].forEach((k, i) => { if (pred(k)) ts.push(mod(i + r - 1)); }); return ts[Math.floor(Math.random() * ts.length)]; }
const SLIP_MAX = 4;       // 目押し: 狙った図柄が中段の4コマ手前までなら引き込める
const CELL_H = 34;   // 絵柄1コマの高さ(px)。CSS の .reels / .reel-ov の高さと揃える
let reelSpin = null;
let isReelSpinning = false;
let reelLocked = false;   // 停止直後の誤タップ防止

function reelsPrepareDOM() {
  reelsEl.innerHTML = Array.from({ length: 9 }, (_, i) => `<div class="reel" style="--i:${i}"></div>`).join('');
}
const colSym = (col, idx) => (col.ov[idx] !== undefined ? col.ov[idx] : stripSym(col.c, idx));

function startReels(plan, onDone) {
  if (window.flag7Game && !plan.assist) plan.flag7 = true;   // ボーナスフラグ中: 目押しで7が揃えられる
  if (window.wmNext) { plan.wm = true; window.wmNext = false; }   // 白7・スイカ・白7 を第1リールに止める（当選確定のゲームだけ）
  if (!naviOrder) { delete spinBtn.dataset.navi; delete document.body.dataset.navi; if (naviEl) naviEl.className = 'navi'; }   // ナビなしの回転: 残っている押し順の表示を消す
  reelsPrepareDOM();
  bellBadge.classList.remove('show');
  alignDisplay.classList.remove('show-align');
  alignDisplay.classList.add('show-lose');
  gogoTextContainer.classList.add('opacity-0');
  const cols = [0, 1, 2].map(c => {
    const el = document.createElement('div');
    el.className = 'reel-ov';
    el.style.left = `${c * 66}px`;
    el.dataset.c = c;
    el.innerHTML = '<div class="reel"></div><div class="reel"></div><div class="reel"></div><div class="reel"></div>';
    reelsEl.appendChild(el);
    return { c, el, cells: [...el.children], pos: Math.random() * STRIP_LEN, state: 'spin', ov: {}, T: 0, t: 0, final: null, shown: [null, null, null, null] };
  });
  reelSpin = { plan, cols, onDone, last: performance.now(), raf: 0, color: plan.color || null, timers: [], order: [] };
  isReelSpinning = true;
  spinBtn.disabled = false;
  spinBtn.innerText = spinBtn.dataset.navi ? `ストップ ${spinBtn.dataset.navi}` : 'ストップ';
  cols.forEach(drawOverlay);
  reelSpin.raf = requestAnimationFrame(reelFrame);
  if (AUTO_STOP) STOP_RULES.autoOrder(plan, naviOrder).forEach((c, i) => reelSpin.timers.push(setTimeout(() => stopCol(c, true), 380 + i * 260)));   // 押し順ナビがあればナビ順 / なければ左→中→右 (サンド目は中→左→右)
}

function drawOverlay(col) {
  const mid = Math.floor(col.pos);
  const f = col.pos - mid;
  for (let j = 0; j < 4; j++) {
    const k = 2 - j;                       // 上のはみ出し(2) / 上段(1) / 中段(0) / 下段(-1)
    const idx = mid + k;
    if (col.shown[j] !== idx) {
      col.cells[j].innerHTML = symbolHTML(colSym(col, idx), '');
      col.shown[j] = idx;
    }
    const sc = window.REEL_SC || 1;   // 描画ピクセルに揃えてにじみを防ぐ
    col.cells[j].style.transform = `translate3d(0,${Math.round((1 - k + f) * CELL_H * sc) / sc}px,0)`;
  }
}

function reelFrame(now) {
  const rs = reelSpin;
  if (!rs) return;
  const dt = Math.min(0.05, (now - rs.last) / 1000);
  rs.last = now;
  rs.cols.forEach(col => {
    if (col.state === 'landed') return;
    col.pos += SPIN_SPEED * dt;
    if (col.state === 'slip' && col.pos >= col.T) { landCol(col); return; }
    drawOverlay(col);
  });
  if (rs.cols.every(col => col.state === 'landed')) { finishReels(); return; }
  rs.raf = requestAnimationFrame(reelFrame);
}

function landCol(col) {
  col.pos = col.T;
  col.state = 'landed';
  col.final = [colSym(col, col.T + 1), colSym(col, col.T), colSym(col, col.T - 1)];
  col.el.remove();
  const cells = reelsEl.querySelectorAll(':scope > .reel');
  col.final.forEach((k, r) => { cells[r * 3 + col.c].innerHTML = symbolHTML(k, ''); });
  // 白7・スイカ・白7 が第1リールに止まった直後: 当選確定。サンド目のように派手に
  if (col.c === 0 && reelSpin && reelSpin.plan.wm && col.final.join() === '7white,melon,7white') {
    const F = document.createElement('div');   // 光るのは第1リールだけ
    F.className = 'wm-colflash'; reelsEl.appendChild(F); setTimeout(() => F.remove(), 1800);
    if (typeof sandSound === 'function') sandSound();
    if (window.LCDX && LCDX.wmWin) LCDX.wmWin();
    if (bonusRun && !bonusRun.zone) bonusRun.confirmShown = true;   // PEKA CHANCE: 確定表示のあとは LEVEL UP・枚GET を出さない
  }
  // サンド目(中リールのバー・チェリー・バー)が止まった直後にビカビカ。上乗せなどは第3停止後
  const rs = reelSpin;
  if (col.c === 1 && rs && (rs.plan.kind === 'sand' || sandReachNow) && col.final.join() === 'bar,cherry,bar' && typeof sandFlash === 'function') sandFlash();
}

/* c番目のリールを止める。引き込める範囲(4コマ)で、役に合う位置を選ぶ */
function stopCol(c, auto) {
  const rs = reelSpin;
  if (!rs) return;
  // 停止順・取りこぼしのルールは STOP_RULES (JS/data/stop-rules.js) に集約
  // 押し順ナビ付きのチェリー/スイカ: ナビ通りに止めれば取りこぼさない (サンド目・SUPERの15枚役は目押しなのでナビ一致で自動にしない)
  if (rs.plan.navi && rs.plan.kind !== 'sand' && rs.plan.kind !== 'superbell') {
    if (rs.naviOk === undefined) rs.naviOk = true;
    if (rs.plan.navi[rs.order.length] !== c) rs.naviOk = false;
    if (rs.naviOk) auto = true;
  }
  const col = rs.cols[c];
  if (!col || col.state !== 'spin') return;
  const s = Math.round(col.pos);
  const cands = wideCands(s, STOP_RULES.slip.normal);
  const wide7 = wideCands(s, STOP_RULES.slip.seven);   // 7は激アマ (自力で揃える)
  const p = rs.plan;
  let T = null, t = 0, tele = false, manual = false;
  /* ボーナスフラグ中のゲーム: ランプや確定画面が出ていれば7揃いをアシスト / 出ていなくても、目押しで7が引き込めれば揃えられる */
  if (p.flag7 && !p.assist) {   // ボーナスフラグ中: ランプや確定画面が出ていても、7は自力で揃える (滑りは激アマ)
    if (rs.flag7ok !== false) {
      const want = rs.flag7color || null;
      const a = wide7.find(x => { const k = stripSym(c, x); return isSeven(k) && (!want || k === want); });
      if (a !== undefined) { T = a; t = mod(a); manual = true; rs.flag7color = stripSym(c, a); rs.flag7ok = true; }
    }
    if (!manual) rs.flag7ok = false;
  }
  if (manual) { /* 目押しで7を引き込んだ */ }
  else if (p.kind === 'fixed') {
    tele = true; t = p.ts[c];
  } else if (p.kind === 'melon') {   // 強スイカ: 第1・第2リールは目押し(上段にスイカ)、第3リールだけ自動停止 (揃う形 / 外した形)
    if (c === 2) {
      tele = true;
      const x0 = rs.cols[0], x1 = rs.cols[1];
      const tops = STRIPS[2].map((k, i) => (k === 'melon' ? mod(i - 1) : -1)).filter(v => v >= 0);
      if (x0.state !== 'spin' && x1.state !== 'spin') {
        const win = stripSym(0, x0.t + 1) === 'melon' && stripSym(1, x1.t + 1) === 'melon';
        const pool = win ? tops : STRIPS[2].map((_, i) => i);
        const good = pool.filter(t2 => { const g = gridOf([x0.t, x1.t, t2]), L = alignedLines(g); return leftCherries(g) === 0 && (win ? (L.length === 1 && L[0].i === 0 && L[0].sym === 'melon') : L.length === 0); });
        const use = good.length ? good : pool;
        t = use[Math.floor(Math.random() * use.length)];
      } else t = p.t2;
    } else if (c === 0) {
      const a = cands.find(x => stripSym(0, x + 1) === 'melon');   // 上段にスイカが来る位置
      if (a !== undefined) { T = a; t = mod(a); }
      else { p.missed = true; const ok = cands.filter(x => !windowOf(0, x).includes('cherry')); T = (ok.length ? ok : cands)[0]; t = mod(T); }   // 取りこぼし
    } else {
      const a = cands.find(x => stripSym(1, x + 1) === 'melon');
      if (a !== undefined) { T = a; t = mod(a); }
      else { p.missed = true; tele = true; t = p.t1miss; }   // 外し: 弱チャンス目の形で止まる（取りこぼし）
    }
  } else if (p.kind === 'superbell') {   // SUPERの15枚役: 7の位置は 左下・中段・右上 のランダム。7の段を目押し、残り2つは自動でベル。外すと取りこぼし
    const rowOf = [2, 1, 0], sc = p.sevenCol;
    if (c !== sc) { tele = true; t = stopWhere(c, rowOf[c], k => k === 'bell'); }
    else if (auto) { tele = true; t = stopWhere(c, rowOf[c], isSeven); }
    else {
      const wide = wideCands(s, STOP_RULES.slip.super7);
      const a = wide.find(x => isSeven(windowOf(c, x)[rowOf[c]]));
      if (a !== undefined) { T = a; t = mod(a); }
      else { const b = wide.find(x => !isSeven(windowOf(c, x)[rowOf[c]])); T = b !== undefined ? b : wide[0]; t = mod(T); }   // 外し: 7が来ない
    }
  } else if (p.kind === 'sand') {   // サンド目: 第2リールを目押し (バー・チェリー・バー)。左右は自動
    tele = true; t = p.ts[c];   // 疑似遊戯: 取りこぼしなし (中を押せば必ず揃う)
  } else if (p.kind === 'cherry') {   // チェリー: 左リールで狙う (取りこぼしあり)
    if (c === 0) {
      const a = (p.strong ? cands.find(x => stripSym(0, x) === 'cherry') : cands.find(x => { const w = windowOf(0, x); return w.includes('cherry') && w[1] !== 'cherry'; }))
        ?? cands.find(x => windowOf(0, x).includes('cherry'));
      if (a !== undefined) { T = a; t = mod(a); }
      else {
        const ok = cands.filter(x => !windowOf(0, x).includes('cherry'));
        T = (ok.length ? ok : cands)[0]; t = mod(T);
      }
    } else {
      let pool = cands;
      const others = [0, 1, 2].filter(i => i !== c);
      if (others.every(i => rs.cols[i].state !== 'spin')) {
        const good = pool.filter(x => alignedLines(gridOf([0, 1, 2].map(i => (i === c ? mod(x) : rs.cols[i].t)))).length === 0);
        if (good.length) pool = good;
      }
      T = pool[0]; t = mod(T);
    }
  } else if (p.kind === 'reg') {   // REG: 左・中は同じ色の7、右はBAR (7・7・BAR)
    const want = rs.color;
    const a = wide7.find(x => { const k = stripSym(c, x); return c === 2 ? k === 'bar' : (isSeven(k) && (!want || k === want)); });
    if (a !== undefined) { T = a; t = mod(a); if (c !== 2 && !rs.color) rs.color = stripSym(c, a); }
    else {
      tele = true;
      if (c === 2) t = STRIPS[2].indexOf('bar');
      else { const color = want || SEVENS[Math.floor(Math.random() * 3)]; t = STRIPS[c].indexOf(color); rs.color = color; }
    }
  } else if (p.diag) {   // 白7の斜め揃い (BIG+AT確定): 各リールの指定の段に白7
    const idx = STRIPS[c].indexOf('7white'), row = p.diag[c];
    tele = true; t = mod(row === 0 ? idx - 1 : row === 2 ? idx + 1 : idx); rs.color = '7white';
  } else {   // seven: 同じ色の7を3つ揃える
    const want = rs.color;
    const a = wide7.find(x => { const k = stripSym(c, x); return isSeven(k) && (!want || k === want); });
    if (a !== undefined) {
      T = a; t = mod(a);
      if (!rs.color) rs.color = stripSym(c, a);
    } else if (auto) {
      const color = want || SEVENS[Math.floor(Math.random() * 3)];
      tele = true; t = STRIPS[c].indexOf(color); rs.color = color;
    } else {
      let pool = cands.filter(x => c !== 0 || !windowOf(0, x).includes('cherry'));
      if (!pool.length) pool = cands;
      if (want) { const same = pool.filter(x => stripSym(c, x) === want); if (same.length) pool = same; }   // 予告で出した7の色を優先して揃える
      const others = [0, 1, 2].filter(i => i !== c);
      if (others.every(i => rs.cols[i].state !== 'spin')) {
        const good = pool.filter(x => alignedLines(gridOf([0, 1, 2].map(i => (i === c ? mod(x) : rs.cols[i].t)))).length === 0);
        if (good.length) pool = good;
      }
      T = pool[0]; t = mod(T);
    }
  }
  if (p.wm && c === 0 && !manual) { tele = true; t = 16; }   // 白7(15)・スイカ(16)・白7(17)
  if (tele) {
    // 配列どおりの図柄(3コマ)が、4コマ先に流れてきて止まる
    T = Math.floor(col.pos) + SLIP_MAX;
    const w = windowOf(c, t);
    col.ov = { [T + 1]: w[0], [T]: w[1], [T - 1]: w[2] };
    col.shown = [null, null, null, null];
  }
  col.T = T; col.t = t; col.state = 'slip';
  rs.order.push(c);
  playStopSound(c);   // 押した瞬間に「ドン」
  if (typeof lampEarly === 'function') lampEarly(rs.order.length === 2 ? 's2' : rs.order.length === 3 ? 's3' : '');   // GOGOランプ: 第2停止 / 第3停止で点灯するパターン
  if (typeof donStop === 'function') donStop(rs.order.length, rs.plan);
  if (window.LCDX && LCDX.hintStop) LCDX.hintStop(rs.plan, rs.order.length);
  refreshNavi();
}

/* レバー/タップで、止まっていないリールを左から順に止める */
function stopNextReel() {
  if (!reelSpin) return;
  // 押し順ナビがあればナビ順 / なければ左→中→右 (サンド目は中→左→右)。ルールは STOP_RULES
  const c = STOP_RULES.nextCol(reelSpin, naviOrder);
  if (c !== undefined) { stopCol(c, false); return; }
  const col = reelSpin.cols.find(x => x.state === 'spin');
  if (col) stopCol(col.c, false);
}

function finishReels() {
  const rs = reelSpin;
  reelSpin = null;
  isReelSpinning = false;
  rs.timers.forEach(clearTimeout);
  const f = rs.cols.map(col => col.final);
  const grid = [f[0][0], f[1][0], f[2][0], f[0][1], f[1][1], f[2][1], f[0][2], f[1][2], f[2][2]];
  let success = false;
  if (rs.plan.flag7 && isSeven(f[0][1]) && f[1][1] === f[0][1] && f[2][1] === f[0][1]) success = true;
  else if (rs.plan.kind === 'reg') success = isSeven(f[0][1]) && f[1][1] === f[0][1] && f[2][1] === 'bar';
  else if (rs.plan.kind === 'seven' && rs.plan.diag) success = rs.plan.diag.every((r, c) => f[c][r] === '7white');
  else if (rs.plan.kind === 'seven') success = isSeven(f[0][1]) && f[1][1] === f[0][1] && f[2][1] === f[0][1];
  else if (rs.plan.kind === 'cherry') success = f[0].includes('cherry');
  else if (rs.plan.kind === 'melon') success = f[0][0] === 'melon' && f[1][0] === 'melon' && f[2][0] === 'melon';
  else if (rs.plan.kind === 'sand') success = f[1][0] === 'bar' && f[1][1] === 'cherry' && f[1][2] === 'bar';
  else if (rs.plan.kind === 'superbell') success = [0, 1, 2].every(c => (c === rs.plan.sevenCol ? isSeven(f[c][[2, 1, 0][c]]) : f[c][[2, 1, 0][c]] === 'bell'));   // 7 (位置はランダム) と ベル2つが 左下→右上 の斜めに並ぶ
  spinBtn.innerText = 'レバーON';
  reelLocked = true;
  setTimeout(() => { reelLocked = false; }, 300);
  setTimeout(() => { if (rs.plan.flag7 && success && window.onFlagSeven) window.onFlagSeven(); else rs.onDone({ grid, success, order: rs.order }); }, 220);
}

function cancelReels() {
  if (reelSpin) { cancelAnimationFrame(reelSpin.raf); reelSpin.timers.forEach(clearTimeout); }
  reelSpin = null;
  isReelSpinning = false;
  reelLocked = false;
}

/* 取りこぼし演出: 暗転 + 下降音 + 「取りこぼし」 */
function missEffect() {
  showAtToast('取りこぼし');
  atToast.classList.add('miss');
  cabinetEl.classList.remove('omen-miss');
  void cabinetEl.offsetWidth;
  cabinetEl.classList.add('omen-miss');
  pekaLater(() => cabinetEl.classList.remove('omen-miss'), 900);
  if (soundEnabled) {
    initAudio();
    const t0 = audioCtx.currentTime;
    [392, 330, 262, 196].forEach((f, i) => tone(f, t0 + i * 0.09, 0.22, 'sawtooth', 0.08));
  }
}

/* チェリー/スイカ成立時: リール回転の前に、筐体まわりのランプが光って予告する */
const cabinetEl = document.querySelector('.cabinet');
function omenOff() {
  if (window.LCDX && LCDX.hintClear) LCDX.hintClear();
  if (cabinetEl) cabinetEl.classList.remove('omen', 'omen-melon', 'omen-cherry', 'omen-chance', 'omen-miss');
  sideLampOff();
}
const FAKE_OMEN_RATE = 0.07;   // ハズレ時のフェイク予告 (外れても予告だけ出ることがある)
/* 役ごとの予告: 弱は軽い(チェリー予告) / 強は重い(スイカ予告) */
/* 赤ランプ(チェリー予告)は、チェリー当選の確定か、ボーナス確定中のハズレ（矛盾）のときだけ */
const OMEN_OF = { cherryW: 'cherry', cherryS: 'cherry', melonW: 'melon', chanceW: 'chance', chanceS: 'chance' };
const OMEN_LAMP = LAMP_TABLE.omen;   // 予告の色（赤=チェリー / 緑=スイカ / 紫ピンク=チャンス目）
/* 2択予告: 左右のランプが別の色で光り、その2つの役のどちらかが成立している（外れ・ガセなし） */
const OMEN_GROUP = { bell0: 'bell', bell1: 'bell', bell2: 'bell', replay: 'replay', cherryW: 'cherry', cherryS: 'cherry', melon: 'melon', melonW: 'melon', chanceW: 'chance', chanceS: 'chance' };
const OMEN_PAIRS = [['bell', 'replay'], ['bell', 'cherry'], ['melon', 'cherry'], ['cherry', 'chance'], ['seven', 'bell'], ['seven', 'replay'], ['seven', 'cherry']];   // 7との2択: 7が成立していたら直BIG（普段はもう一方の役）
const OMEN_PAIR_COLOR = { bell: 'yellow', replay: 'blue', cherry: 'red', melon: 'green', chance: 'pink', seven: 'red' };
const PAIR_OMEN_P = 0.1;
function omenThen(kind, go) {
  const pre = window.LCDX && LCDX.preHint ? LCDX.preHint() : 0;   // 図柄示唆(回転前パターン): 図柄を見せてから回転
  if (pre > 0) { reelLocked = true; pekaLater(() => { reelLocked = false; go(); }, pre); return; }
  if (window.contraPair) {   // 矛盾演出: 2択を出すが、結果はその2つのどちらでもない
    const cp = window.contraPair; window.contraPair = null;
    reelLocked = true;
    sideLampPair(OMEN_PAIR_COLOR[cp[0]], OMEN_PAIR_COLOR[cp[1]]);
    if (window.LCDX && LCDX.pair) LCDX.pair(cp[0], cp[1]);
    pekaLater(() => { reelLocked = false; go(); }, 600);
    return;
  }
  const grp = OMEN_GROUP[kind];
  if (grp && Math.random() < PAIR_OMEN_P * (window.FXO_FREQ ? window.FXO_FREQ() : 1)) {
    const cands = OMEN_PAIRS.filter(p => p.includes(grp));
    const pair = cands[Math.floor(Math.random() * cands.length)];
    const ord = Math.random() < 0.5 ? pair : [pair[1], pair[0]];   // 左右はランダムに入れ替え
    reelLocked = true;
    sideLampPair(OMEN_PAIR_COLOR[ord[0]], OMEN_PAIR_COLOR[ord[1]]);
    if (window.LCDX && LCDX.pair) LCDX.pair(ord[0], ord[1]);
    pekaLater(() => { reelLocked = false; go(); }, 600);
    return;
  }
  omenThen2(kind, go);
}
function omenThen2(kind, go) {
  let shown = OMEN_OF[kind] === undefined ? kind : OMEN_OF[kind];
  if (kind === 'lose' && (pendingBonusType || zenchoLeft > 0) && Math.random() < FAKE_OMEN_RATE * 3) shown = pendingBonusType && Math.random() < 0.7 ? 'cherry' : 'melon';
  if (!OMEN_LAMP[shown]) { go(); return; }
  const melon = shown === 'melon', chance = shown === 'chance';
  reelLocked = true;                       // 予告の間はレバー/タップを受けない
  cabinetEl.classList.remove('omen', 'omen-melon', 'omen-cherry', 'omen-chance');
  void cabinetEl.offsetWidth;
  cabinetEl.classList.add('omen', melon ? 'omen-melon' : chance ? 'omen-chance' : 'omen-cherry');
  sideLampShow(OMEN_LAMP[shown]);
  if (soundEnabled) {
    initAudio();
    const t = audioCtx.currentTime;
    const notes = melon ? [392, 494, 587, 784, 988, 1175, 1568] : [880, 1109, 1319];
    notes.forEach((f, i) => tone(f, t + 0.06 + i * (melon ? 0.1 : 0.12), 0.16, 'triangle', 0.1));
    if (melon) tone(98, t, 1.2, 'sine', 0.18);
  }
  pekaLater(() => { reelLocked = false; go(); }, melon ? 640 : 440);   // ランプはリールが止まるまで点灯したまま
}

/* 役の抽選結果を持って回転開始。止まったら done(結果) */
function runRole(kind, done, navi) {
  clearChance();
  omenThen(kind, () => {
    const plan = planFor(kind);
    plan.role = kind;
    if (navi) { plan.navi = navi.order; showNavi(navi.order, navi.style, false, navi.seven); }
    if (window.LCDX && LCDX.spinStart) setTimeout(LCDX.spinStart, 0);
    startReels(plan, res => {
      omenOff();
      if (navi) {
        hideNavi();
        // 押し順がナビと違ったとき: 一言と下降音でわかるようにする
        if (res.order && res.order.some((c, i) => c !== navi.order[i])) {
          showAtToast('ナビ違い');
          if (window.LCDX) { LCDX.say('', 'ナビ違い！', 2300, 'angry'); LCDX.act('angry'); }
          if (soundEnabled) { initAudio(); const t0 = audioCtx.currentTime; [330, 247].forEach((f, i) => tone(f, t0 + i * 0.1, 0.18, 'triangle', 0.1)); }
        }
      }
      markWin(winIdxOf(kind, res.grid), '');
      markChance(kind, res.grid);
      done(res);
    });
  });
}
/* 押し順ナビ。first を指定すると、そのリールを必ず1番目にする(スイカ・チェリーは左から / サンド目は中から) */
const naviFor = (style, first) => {
  const rest = [0, 1, 2].filter(c => c !== first).sort(() => Math.random() - 0.5);
  return { order: first === undefined ? [0, 1, 2].sort(() => Math.random() - 0.5) : [first, ...rest], style };
};

/* 揃ったマスを光らせる / ほかを暗くする */
function markWin(winIdx, glow) {
  reelsEl.querySelectorAll(':scope > .reel').forEach((el, i) => {
    const w = !!winIdx && winIdx.includes(i);
    el.classList.toggle('win', w);
    el.classList.toggle('dim', !!winIdx && !w);
    const img = el.querySelector('.sym-img');
    if (img && glow) img.classList.toggle(glow, w);
  });
  drawPayline(winIdx);
}
/* チャンス目: 対象の絵柄だけ光らせ、ほかは暗くする (弱=スイカ / 強=7) */
function markChance(kind, grid) {
  const want = null;   // チャンス目は揃っていない形なので、スイカを光らせたり他を暗くしたりしない（揃ったように見えるため）
  reelsEl.classList.toggle('has-chance', !!want);
  reelsEl.querySelectorAll(':scope > .reel').forEach((el, i) => {
    const sym = grid[i];
    el.classList.toggle('chance-sym', !!want && sym === want);
  });
}
function clearChance() {
  reelsEl.classList.remove('has-chance');
  reelsEl.querySelectorAll('.chance-sym').forEach(el => el.classList.remove('chance-sym'));
}
/* 揃ったラインを光る線で示す (チェリーは1コマなので線なし) */
function drawPayline(winIdx) {
  const old = reelsEl.querySelector(':scope > .payline');
  if (old) old.remove();
  return;   // 1.19.31: 揃ったラインの線は表示しない
  if (!winIdx || winIdx.length < 3) return;
  const c = i => [(i % 3) * 66 + 33, Math.floor(i / 3) * CELL_H + CELL_H / 2];
  const [x1, y1] = c(winIdx[0]);
  const [x2, y2] = c(winIdx[winIdx.length - 1]);
  const dx = (x2 - x1) * 0.28, dy = (y2 - y1) * 0.28;   // 両端を少し延ばす
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('class', 'payline');
  svg.setAttribute('viewBox', `0 0 198 ${CELL_H * 3}`);
  const ln = document.createElementNS(ns, 'line');
  ln.setAttribute('x1', x1 - dx); ln.setAttribute('y1', y1 - dy);
  ln.setAttribute('x2', x2 + dx); ln.setAttribute('y2', y2 + dy);
  svg.appendChild(ln);
  reelsEl.appendChild(svg);
}

/* 回さずに、止まった状態で表示 (デバッグ用) */
function showStatic(g, winIdx, glow) {
  bellBadge.classList.remove('show');
  renderReels(g, winIdx, glow || '');
  alignDisplay.classList.remove('show-align');
  alignDisplay.classList.add('show-lose');
  gogoTextContainer.classList.add('opacity-0');
}

function playStopSound(c = 0) {
  if (!soundEnabled) return;
  initAudio();
  const t = audioCtx.currentTime;
  const k = [1.12, 1, 0.88][c] || 1;   // 左 → 中 → 右で少しずつ低くなる「ドン」「ドン」「ドン」
  tone(300 * k, t, 0.05, 'square', 0.18);                       // 打撃のアタック
  const o = audioCtx.createOscillator(), g = audioCtx.createGain();   // 腹に響く低音
  o.type = 'sine';
  o.frequency.setValueAtTime(170 * k, t);
  o.frequency.exponentialRampToValueAtTime(42, t + 0.26);
  g.gain.setValueAtTime(0.7 + c * 0.08, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
  o.connect(g); g.connect(audioCtx.destination);
  o.start(t); o.stop(t + 0.32);
  tone(80 * k, t, 0.16, 'triangle', 0.3);
}

